const { MongoClient } = require("mongodb");
const cors = require('cors');
require("dotenv").config();
const express = require("express");
const app = express();
app.use(express.static("build"));
app.use(express.json());
app.use(cors());
app.listen(process.env.PORT, () => {
  console.log(`Listening on port ${process.env.PORT}`);
});
console.log(process.env.connectionString);
const client = new MongoClient(process.env.connectionString);
// client.connect(() => {
//   console.log("Connected");
// });
// console.clear();
const db = client.db("MCQ");
const questions = db.collection("quiz");
const useranswers = db.collection("users");
app.post("/getq", async (req, res) => {
  const { userName } = req.body;
  const quiz = await questions.find().toArray();
  const findUser = await useranswers.findOne({ userName });
  let locked = false;
  quiz.forEach((question) => {
    delete question._id;
    delete question.answer;
  });
  if (findUser) {
    const answers = findUser.answers;
    if (answers) {
      answers.forEach((item) => {
        if (item.answer)
          quiz[item.questionIndex].storedAnswer = item.answer;
      });
    }
  }
  if (findUser.locked)
    locked = findUser.locked;
  return res.json({ quiz, locked });
});
app.post("/newquestion", async (req, res) => {
  const { question, options, answer } = req.body;
  const reply = await questions.insertOne({ question, options, answer });
  return res.send(reply);
});

app.post("/usersubmit", async (req, res) => {
  let update = false;
  let status;
  let toBeDeleted = [];
  const { userName, submission } = req.body;
  console.log(req.body);
  let answersLoc = [];
  let reply = await useranswers.findOne({ userName });
  console.log(reply);
  if (!reply.answers) {
    submission.forEach((item, index) => {
      if (item != null) {
        answersLoc.push({ questionIndex: index, answer: item })
      };
    });
    status = await useranswers.updateOne({ userName }, { $set: { answers: answersLoc } });
    return res.json({ status });
  }
  let userSubmissions = await reply.answers;
  submission.forEach((item, index) => {
    if (userSubmissions) {
      update = false;
      userSubmissions.forEach((submission) => {
        if (submission.questionIndex == index) {
          update = true;
          if (item == null) {
            toBeDeleted.push(userSubmissions.indexOf(submission));
          } else if (submission.answer != item) {
            submission.answer = item;
          }
        }
      });
      if (update == false) {
        if (item != null)
          userSubmissions.push({ questionIndex: index, answer: item });
      }
    }
  });
  toBeDeleted.sort();
  for (let i = toBeDeleted.length - 1; i >= 0; i--) {
    userSubmissions.splice(toBeDeleted[i], 1);
  }
  status = await useranswers.updateOne(
    { userName },
    { $set: { answers: userSubmissions } }
  );
  return res.json({ status });

});
app.post("/login", async (req, res) => {
  const { userName, password } = req.body;
  const user = await useranswers.findOne({ userName, password });
  if (user !== null) {
    return res.send(user.name);
  } else return res.send("1");
});
app.post("/checker", async (req, res) => {
  let analysis = [];
  let answered = [];
  let allSet = [];
  let score = 0;
  let notAnswered = 0;
  console.log(req.body);
  const { userName } = req.body;
  const quizReply = await questions.find().toArray();
  const user = await useranswers.findOne({ userName });
  console.log(user.answers);
  if (user.answers) {
    const answers = user.answers;
    for (let i = 0; i < quizReply.length; i++) {
      allSet.push(i);
    }
    console.log(answers);
    answers.forEach((answer) => {
      if (quizReply[answer.questionIndex].answer == answer.answer) {
        score++;
        analysis.push(
          `${answer.questionIndex + 1}. Right answer: ${quizReply[answer.questionIndex].answer
          }, your answer: ${answer.answer} ✅`
        );
      }
      else if (answer.answer == '') {
        notAnswered++;
        analysis.push(
          `${answer.questionIndex + 1}. Right answer: ${quizReply[answer.questionIndex].answer
          }, your answer:Not answered ❎`
        );
      }
      else {
        analysis.push(
          `${answer.questionIndex + 1}. Right answer: ${quizReply[answer.questionIndex].answer
          }, your answer: ${answer.answer} ❌`
        );
      }
      answered.push(answer.questionIndex);
    });
    allSet.forEach((number) => {
      if (answered.indexOf(number) === -1) {
        notAnswered++;
        analysis.push(
          `${number + 1}. Right answer: ${quizReply[number].answer
          } your answer: Not answered ❎`
        );
      }
    });
    console.log(
      `Total questions:${quizReply.length}, not naswered: ${notAnswered
      }, wrong answers:${answers.length - score}.`
    );
    console.log(analysis.sort());
    return res.json({ score, analysis });
  } else {
    return res.json({ score, analysis });
  }
});

app.put('/locksession', async (req, res) => {
  console.log('Locked', req.body);
  const { userName } = req.body;
  const reply = await useranswers.updateOne({ userName }, { $set: { locked: true } });
  return res.send(reply);
})

app.put('/unlocksession', async (req, res) => {
  console.log('Unlocked', req.body);
  const { userName } = req.body;
  const reply = await useranswers.updateOne({ userName }, { $set: { locked: false } });
  return res.send(reply);

})

app.get("/checker/:userName", async (req, res) => {
  let analysis = [];
  let answered = [];
  let allSet = [];
  let score = 0;
  let notAnswered = 0;
  const { userName } = req.params;
  const quizReply = await questions.find().toArray();
  const user = await useranswers.findOne({ userName });
  console.log(user);
  const name = await user.name;
  console.log(user.answers);
  if (user.answers) {
    const answers = user.answers;
    for (let i = 0; i < quizReply.length; i++) {
      allSet.push(i);
    }
    console.log(answers);
    answers.forEach((answer) => {
      if (quizReply[answer.questionIndex].answer == answer.answer) {
        score++;
        analysis.push(
          `${answer.questionIndex + 1}. Right answer: ${quizReply[answer.questionIndex].answer
          }. Your answer: ${answer.answer} ✅`
        );
      }
      else if (answer.answer == '') {
        notAnswered++;
        analysis.push(
          `${answer.questionIndex + 1}. Right answer: ${quizReply[answer.questionIndex].answer
          }. Your answer:Not answered ❎`
        );
      }
      else {
        analysis.push(
          `${answer.questionIndex + 1}. Right answer: ${quizReply[answer.questionIndex].answer
          }. Your answer: ${answer.answer} ❌`
        );
      }
      answered.push(answer.questionIndex);
    });
    allSet.forEach((number) => {
      if (answered.indexOf(number) === -1) {
        notAnswered++;
        analysis.push(
          `${number + 1}. Right answer: ${quizReply[number].answer
          }. Your answer: Not answered ❎`
        );
      }
    });
    console.log(
      `Total questions:${quizReply.length}, not naswered: ${notAnswered
      }, wrong answers:${answers.length - score}.`
    );
    console.log(analysis.sort());
    return res.json({ name, score, analysis });
  } else {
    return res.json({ name, score, analysis });
  }
});