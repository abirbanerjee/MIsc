const submit = document.getElementById("submit");
var elem = document.documentElement;

submit.addEventListener("click", async (e) => {
  // if (elem.requestFullscreen) {
  //   elem.requestFullscreen();
  // }
  const userName = document.querySelector("#uid").value;
  const password = document.querySelector("#pass").value;
  const reply = await axios.post("/login", { userName, password });
  if (reply.data != 1) {
    localStorage.setItem("userName", userName);
    localStorage.setItem("name", reply.data);
    window.location.replace("/quiz.html");
  }
});
