const qdiv = document.querySelector("#qdiv");
const linebreak = document.createElement("br");
const submitButton = document.createElement("button");
const nextButton = document.createElement("button");
const prevButton = document.createElement("button");
const userName = localStorage.getItem("userName");

prevButton.innerText = "Previous";
prevButton.disabled = true;
const clearButton = document.createElement("button");
clearButton.innerHTML = "Clear";
clearButton.disabled = true;
let quizlength = 0;
let quizNo = 0;
let selectedOption = "";
let quiz = [];
let locked = false;
window.addEventListener('keydown', blocker);
window.addEventListener('blur', blocker);

if (localStorage.getItem("userName") == undefined) {
  window.location.replace("/");
}
const getquiz = async () => {
  const reply = await axios.post("/getq", {
    userName,
  });
  quiz = await reply.data.quiz;
  quizlength = await quiz.length;
  locked = await reply.data.locked;
  if (locked) {
    const blockedDiv = document.createElement('div');
    blockedDiv.classList.add('overlay');
    const alert = document.createElement('h2');
    alert.innerText = 'You pressed a key, your session is locked.\n Enter admin password to unlock.';
    blockedDiv.append(alert);
    qdiv.append(blockedDiv);
    window.addEventListener('keydown', blocker);
  }
  document.getElementById("greet").innerText =
    "Hello, " + localStorage.getItem("name");
  return await quiz;
};

const loadquiz = async () => {
  qdiv.innerHTML = "";
  if (quizlength == 0) quiz = await getquiz();
  console.log(quiz);
  const question = document.createElement("a2");
  question.innerText = quiz[quizNo].question + "\n";
  qdiv.appendChild(question);
  qdiv.appendChild(linebreak);
  const options = quiz[quizNo].options;
  options.forEach((option, index) => {
    const oplabel = document.createElement("label");
    oplabel.innerText = option + "\n";
    oplabel.id = index;
    const radioop = document.createElement("input");
    radioop.type = "radio";
    radioop.name = "option";
    radioop.id = index;
    radioop.addEventListener("click", (e) => {
      selectedOption = options[e.target.id];
      console.log(selectedOption);
      quiz[quizNo].storedAnswer = selectedOption;
      clearButton.disabled = false;
      clearButton.addEventListener("click", () => {
        const selected = document.getElementById(e.target.id);
        selected.checked = false;
        clearButton.disabled = true;
        quiz[quizNo].storedAnswer = "";
        delete quiz[quizNo].storedAnswer;
      });
    });
    oplabel.addEventListener("click", (e) => {
      const getid = e.target.id;
      selectedOption = options[getid];
      const selectrad = document.getElementById(getid);
      selectrad.checked = true;
      quiz[quizNo].storedAnswer = options[getid];
      console.log(quiz[quizNo].storedAnswer)

      clearButton.disabled = false;
      clearButton.addEventListener("click", () => {
        selectrad.checked = false;
        clearButton.disabled = true;
        quiz[quizNo].storedAnswer = "";
      });
    });
    qdiv.appendChild(radioop);
    qdiv.appendChild(oplabel);
    qdiv.appendChild(linebreak);
  });
  if ("storedAnswer" in quiz[quizNo] && quiz[quizNo].storedAnswer != "") {
    console.log(quiz[quizNo].storedAnswer);
    const indexOfAnswer = quiz[quizNo].options.indexOf(
      quiz[quizNo].storedAnswer
    );
    document.getElementById(indexOfAnswer).checked = true;
    selectedOption = quiz[quizNo].storedAnswer;
    clearButton.addEventListener("click", () => {
      document.getElementById(
        quiz[quizNo].options.indexOf(quiz[quizNo].storedAnswer)
      ).checked = false;
      clearButton.disabled = true;
      delete quiz[quizNo].storedAnswer;
      console.log(quiz[quizNo]);
      quiz[quizNo].storedAnswer = null;
    });
    clearButton.disabled = false;
  }
};
if (localStorage.getItem("userName") != undefined) loadquiz();
nextButton.innerHTML = "Next";
nextButton.addEventListener("click", (e) => {
  prevButton.disabled = false;
  if (quizNo < quizlength - 1) {
    quizNo++;
    if (quizNo == quizlength - 1) e.target.disabled = true;
    loadquiz();
  }
});
document.body.append(prevButton);
document.body.append(clearButton);
document.body.append(nextButton);
submitButton.innerHTML = "Submit";
submitButton.addEventListener("click", () => {
  let submission = [];
  quiz.forEach((item) => {
    submission.push(item.storedAnswer);
  });
  axios.post("/usersubmit", { userName, submission });
  localStorage.clear();
  window.location.replace("/");
});
document.body.append(submitButton);
prevButton.addEventListener("click", (e) => {
  nextButton.disabled = false;
  if (quizNo > 0) {
    quizNo--;
    if (quizNo == 0) e.target.disabled = true;
  }
  loadquiz();
});


async function blocker(e) {
  const blockedDiv = document.createElement('div');
  if (!locked) {
    blockedDiv.classList.add('overlay');
    const alert = document.createElement('h2');
    alert.innerText = 'You pressed a key, your session is locked.\n Enter admin password to unlock.';
    blockedDiv.append(alert);
    qdiv.append(blockedDiv);
    locked = true;
    await axios.put('/locksession', { userName });
  }
  if (e.key == '|') {
    if (locked) {
      qdiv.remove(blockedDiv);
      locked = false;
      await axios.put('/unlocksession', { userName });
      loadquiz();
    }
  }
}